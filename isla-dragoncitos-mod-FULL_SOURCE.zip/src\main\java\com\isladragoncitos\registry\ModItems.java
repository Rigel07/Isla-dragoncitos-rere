package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item. crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeIngredients;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, IslaDragoncitosMod.MODID);

    // --- ITEMS DE MATERIALES ESPECIALES (Para Crafteos) ---
    public static final RegistryObject<Item> DRAGON_ESSENCE = ITEMS.register("dragon_essence", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TIME_SHARD = ITEMS.register("time_shard", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> COSMIC_DUST = ITEMS.register("cosmic_dust", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> VOID_CORE = ITEMS.register("void_core", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SOLAR_FLAKE = ITEMS.register("solar_flake", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> LUNAR_TEAR = ITEMS.register("lunar_tear", () -> new Item(new Item.Properties()));

    // --- ITEMS DE EQUIPAMIENTO ÚNICO (Asociados a Dragones) ---
    // Armadura y Armas basadas en los Tipos
    public static final RegistryObject<Item> CHRONOS_SICKLE = ITEMS.register("chronos_sickle", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> OMEGA_PLATE = ITEMS.register("omega_plate", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> PSYCHE_CROWN = ITEMS.//Cope with tooltips
    public static final RegistryObject<Item> FORTUNA_COIN = ITEMS.register("fortuna_coin", () -> new Item(new Item.Properties()));

    // Items de soporte
    public static final RegistryObject<Item> DRAGON_CODEX = ITEMS.register("dragon_codex", () -> new com.isladragoncitos.item.DragonCodexItem(new Item.Properties()));
    public static final RegistryObject<Item> DRACONIC_MANUSCRIPT = ITEMS.register("draconic_manuscript", () -> new Item(new Item.Properties()));

    private ModItems() {}
}
