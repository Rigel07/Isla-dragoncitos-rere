package com.isladragoncitos.worldgen.lifetree;

import com.isladragoncitos.system.DraconicData;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

public class TreeOfLifeHandler {
    public static void onTouch(ServerPlayer player) {
        if (DraconicData.findSharedDragon(player) == null) {
            player.displayClientMessage(Component.literal("§cAún no has vinculado tu vida con un dragón. El Árbol de la Vida no te reconoce."), false);
            return;
        }

        if (DraconicData.getMarkLevel(player) < 2) {
            DraconicData.setMarkLevel(player, 2);
            DraconicData.addHalfPoints(player, 100); // 50 puntos = 100 half-points

            // Unlock random ability
            String[] abilities = {"dragon_nova", "ether_breath", "scale_shield", "sonic_flight"}; // Simplified list
            String randomAbility = abilities[new java.util.Random().nextInt(abilities.length)];
            DraconicData.unlockAbility(player, randomAbility);

            player.displayClientMessage(Component.literal("§6§l¡BENDICIÓN DEL ÁRBOL DE LA VIDA!§r"), false);
            player.displayClientMessage(Component.literal("§eMarca Nivel 2 activa: Vida compartida x2, +50 Puntos y habilidad: " + randomAbility), false);
        } else {
            player.displayClientMessage(Component.literal("§7Ya has recibido la bendición del Árbol de la Vida."), false);
        }
    }

    public static void spawnLoot(Level level, BlockPos pos) {
        // logic to spawn golden apples and random items
        if (level.isClientSide) return;

        // Golden Apple
        level.dropLoot(pos, new ItemStack(Items.GOLDEN_APPLE));

        if (Math.random() < 0.05) {
            // Logic to get a random item from all registered items
            // For simplicity, spawning a netherite ingot
            level.dropLoot(pos, new ItemStack(Items.NETHERITE_INGOT));
        }
    }
}
