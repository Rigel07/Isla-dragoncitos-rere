package com.isladragoncitos.worldgen;

import com.isladragoncitos.registry.ModStructures;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/** Ruinas de la civilizacion desaparecida de los Jinetes del Alba (atalaya, cementerio de dragones, circulo, pilar marino). */
public class RiderRuinStructure extends Structure {
    public static final Codec<RiderRuinStructure> CODEC = RecordCodecBuilder.create(instance -> instance
            .group(settingsCodec(instance), Codec.INT.fieldOf("kind").forGetter(structure -> structure.kind))
            .apply(instance, RiderRuinStructure::new));

    private final int kind;

    public RiderRuinStructure(Structure.StructureSettings settings, int kind) {
        super(settings);
        this.kind = kind;
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.RUIN_TYPE.get();
    }

    private int height(Structure.GenerationContext context, int x, int z, Heightmap.Types type) {
        return context.chunkGenerator().getFirstOccupiedHeight(x, z, type, context.heightAccessor(), context.randomState());
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        ChunkPos chunk = context.chunkPos();
        int x = chunk.getMiddleBlockX();
        int z = chunk.getMiddleBlockZ();
        boolean sea = this.kind == RiderRuinPiece.SEA;
        Heightmap.Types type = sea ? Heightmap.Types.OCEAN_FLOOR_WG : Heightmap.Types.WORLD_SURFACE_WG;
        int h = this.height(context, x, z, type);
        NoiseColumn column = context.chunkGenerator().getBaseColumn(x, z, context.heightAccessor(), context.randomState());
        if (sea) {
            if (!column.getBlock(h).is(Blocks.WATER) || !column.getBlock(h + 6).is(Blocks.WATER)) {
                return Optional.empty();
            }
        } else {
            if (!column.getBlock(h - 1).getFluidState().isEmpty() || h < 58) {
                return Optional.empty();
            }
            int spread = this.kind == RiderRuinPiece.GRAVEYARD ? 14 : 6;
            int limit = this.kind == RiderRuinPiece.GRAVEYARD ? 9 : 5;
            int min = h;
            int max = h;
            int[][] offsets = {{spread, 0}, {-spread, 0}, {0, spread}, {0, -spread}};
            for (int[] offset : offsets) {
                int other = this.height(context, x + offset[0], z + offset[1], type);
                min = Math.min(min, other);
                max = Math.max(max, other);
            }
            if (max - min > limit) {
                return Optional.empty();
            }
        }
        long seed = context.random().nextLong();
        int rot = context.random().nextInt(4);
        int baseY = h;
        return Optional.of(new Structure.GenerationStub(new BlockPos(x, baseY, z),
                builder -> builder.addPiece(new RiderRuinPiece(this.kind, x, baseY, z, seed, rot))));
    }
}
