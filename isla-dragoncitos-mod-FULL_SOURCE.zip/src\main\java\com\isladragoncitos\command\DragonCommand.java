package com.isladragoncitos.command;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.island.Island;
import com.isladragoncitos.island.IslandRegistry;
import com.isladragoncitos.item.DragonCompassItem;
import com.isladragoncitos.system.DraconicData;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /dragon: menu con botones clicables para dar ordenes al dragon antiguo y gastar puntos draconianos. */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID)
public final class DragonCommand {
    private static final String[] STATS = {"fuerza", "velocidad", "vida", "escamas", "vida_compartida"};

    private DragonCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dragon")
                .executes(c -> openGui(c.getSource()))
                .then(Commands.literal("texto").executes(c -> menu(c.getSource())))
                .then(Commands.literal("seguir").executes(c -> order(c, "seguir")))
                .then(Commands.literal("quedarse").executes(c -> order(c, "quedarse")))
                .then(Commands.literal("deambular").executes(c -> order(c, "deambular")))
                .then(Commands.literal("explorar").executes(c -> order(c, "explorar")))
                .then(Commands.literal("parar").executes(c -> order(c, "parar")))
                .then(Commands.literal("buscar").executes(c -> order(c, "buscar")))
                .then(Commands.literal("estado").executes(c -> status(c.getSource())))
                .then(Commands.literal("ir").then(Commands.argument("isla", StringArgumentType.greedyString())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(islandNames(c.getSource()), b))
                        .executes(c -> goTo(c.getSource(), StringArgumentType.getString(c, "isla")))))
                .then(Commands.literal("apodar").then(Commands.argument("nombre", StringArgumentType.greedyString())
                        .executes(c -> rename(c.getSource(), StringArgumentType.getString(c, "nombre")))))
                .then(Commands.literal("mejorar").then(Commands.argument("mejora", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(STATS, b))
                        .executes(c -> upgrade(c.getSource(), StringArgumentType.getString(c, "mejora"), 1))
                        .then(Commands.argument("niveles", IntegerArgumentType.integer(1, 1000))
                                .executes(c -> upgrade(c.getSource(), StringArgumentType.getString(c, "mejora"),
                                        IntegerArgumentType.getInteger(c, "niveles")))))));
    }

    private static AncientDragonEntity dragonOf(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        AncientDragonEntity dragon = DraconicData.findDragon(player);
        if (dragon == null) {
            source.sendFailure(Component.literal("No encuentro a tu dragón: está lejos, dentro del báculo o aún no tienes uno."));
        }
        return dragon;
    }

    private static MutableComponent button(String label, String command, int color, String hint) {
        return Component.literal("[" + label + "]").withStyle(style -> style.withColor(color)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(hint))));
    }

    private static List<String> islandNames(CommandSourceStack source) {
        List<String> names = new ArrayList<>();
        if (source.getEntity() instanceof ServerPlayer player) {
            for (Island island : IslandRegistry.get(source.getServer()).all()) {
                if (island.canAccess(player.getUUID())) {
                    names.add(island.name);
                }
            }
        }
        return names;
    }

    /** /dragon abre el menu grafico (tambien se abre con la tecla G). */
    private static int openGui(CommandSourceStack source) throws CommandSyntaxException {
        com.isladragoncitos.network.DragonMenuServer.handle(source.getPlayerOrException(),
                new com.isladragoncitos.network.DragonRequestPacket(com.isladragoncitos.network.DragonRequestPacket.OPEN, "", 0));
        return 1;
    }

    private static int menu(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        MutableComponent text = Component.literal("§6§l=== Tu dragón antiguo ===\n");
        text.append(Component.literal("§7Puntos draconianos: §f" + DraconicData.formatPoints(DraconicData.getHalfPoints(player))
                + "  §7Islas halladas: §f" + DraconicData.islandsFound(player)
                + (DraconicData.hasMark(player) ? "  §6Marca del Jinete" : "") + "\n"));
        text.append(button("Seguir", "/dragon seguir", 0x55FF55, "Te sigue")).append(" ");
        text.append(button("Quedarse", "/dragon quedarse", 0xFFAA00, "Se queda donde está")).append(" ");
        text.append(button("Deambular aquí", "/dragon deambular", 0x55FFFF, "Pasea en 32 bloques alrededor de ti")).append("\n");
        text.append(button("Explorar", "/dragon explorar", 0xFF55FF, "Explora solo (vuela o camina como estuviera)")).append(" ");
        text.append(button("Isla cercana", "/dragon buscar", 0xFFFF55, "Te lleva a la isla de dragoncitos más cercana")).append(" ");
        text.append(button("Parar", "/dragon parar", 0xFF5555, "Cancela la orden actual")).append("\n");
        text.append(button("Estado y mejoras", "/dragon estado", 0xAAAAAA, "Ver niveles y mejorar")).append("\n");
        List<String> names = islandNames(source);
        if (!names.isEmpty()) {
            text.append(Component.literal("§7Ir a: "));
            for (String name : names) {
                text.append(button(name, "/dragon ir " + name, 0x55AAFF, "Vuelo automático a esta isla")).append(" ");
            }
        }
        source.sendSystemMessage(text);
        return 1;
    }

    private static int order(CommandContext<CommandSourceStack> context, String what) throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        ServerPlayer player = source.getPlayerOrException();
        AncientDragonEntity dragon = dragonOf(source);
        if (dragon == null) {
            return 0;
        }
        switch (what) {
            case "seguir" -> {
                dragon.orderFollow();
                source.sendSystemMessage(Component.literal("Tu dragón te sigue."));
            }
            case "quedarse" -> {
                dragon.orderStay();
                source.sendSystemMessage(Component.literal("Tu dragón se queda aquí."));
            }
            case "deambular" -> {
                dragon.orderWander(player.blockPosition());
                source.sendSystemMessage(Component.literal("Tu dragón deambulará en 32 bloques alrededor de este punto."));
            }
            case "explorar" -> {
                dragon.orderExplore();
                source.sendSystemMessage(Component.literal("Tu dragón se pone a explorar. Muévete (teclas) para retomar el control."));
            }
            case "parar" -> {
                dragon.orderFollow();
                source.sendSystemMessage(Component.literal("Orden cancelada."));
            }
            default -> {
                ServerLevel level = (ServerLevel) dragon.level();
                BlockPos found = level.findNearestMapStructure(DragonCompassItem.ISLANDS, dragon.blockPosition(), 100, false);
                if (found == null) {
                    source.sendFailure(Component.literal("Tu dragón no percibe ninguna isla de dragoncitos cerca."));
                    return 0;
                }
                dragon.orderGoto(new Vec3(found.getX() + 0.5D, dragon.getY() + 12.0D, found.getZ() + 0.5D), "la isla más cercana", true);
                source.sendSystemMessage(Component.literal("Tu dragón huele una isla de dragoncitos y te lleva hacia ella."));
            }
        }
        return 1;
    }

    private static int goTo(CommandSourceStack source, String name) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        AncientDragonEntity dragon = dragonOf(source);
        if (dragon == null) {
            return 0;
        }
        for (Island island : IslandRegistry.get(source.getServer()).all()) {
            if (island.name.equalsIgnoreCase(name.trim()) && island.canAccess(player.getUUID())) {
                dragon.orderGoto(new Vec3(island.pos.getX() + 5.5D, island.pos.getY() - 1.0D, island.pos.getZ() + 0.5D), island.name, false);
                source.sendSystemMessage(Component.literal("Tu dragón te lleva a " + island.name + "."));
                return 1;
            }
        }
        source.sendFailure(Component.literal("No conoces ninguna isla llamada \"" + name + "\"."));
        return 0;
    }

    private static int rename(CommandSourceStack source, String name) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        String clean = name.trim();
        if (clean.isEmpty() || clean.length() > 24) {
            source.sendFailure(Component.literal("El nombre debe tener entre 1 y 24 caracteres."));
            return 0;
        }
        IslandRegistry registry = IslandRegistry.get(source.getServer());
        Island island = registry.findAt(player.blockPosition());
        if (island == null) {
            source.sendFailure(Component.literal("Ponte sobre una isla reclamada para apodarla."));
            return 0;
        }
        if (!island.isOwner(player.getUUID())) {
            source.sendFailure(Component.literal("Solo el dueño de la isla puede apodarla."));
            return 0;
        }
        island.name = clean;
        registry.setDirty();
        source.sendSystemMessage(Component.literal("La isla ahora se llama " + clean + ". Dile a tu dragón: /dragon ir " + clean));
        return 1;
    }

    private static int status(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        AncientDragonEntity dragon = dragonOf(source);
        if (dragon == null) {
            return 0;
        }
        String[] type = {"de Fuego", "de Hielo", "de Tormenta", "del Agua"};
        MutableComponent text = Component.literal("§6§l=== Dragón " + type[dragon.getDragonType()] + " ===\n");
        text.append(Component.literal("§7Tamaño: §f" + String.format("%.1f", dragon.getVisualScale()) + " §7(comida " + dragon.getFood() + "/"
                + AncientDragonEntity.FOOD_MAX + ")  Vida: §f" + (int) dragon.getHealth() + "/" + (int) dragon.getMaxHealth() + "\n"));
        text.append(Component.literal("§7Puntos: §f" + DraconicData.formatPoints(DraconicData.getHalfPoints(player)) + "\n"));
        addStat(text, "fuerza", dragon.getStrengthLvl(), AncientDragonEntity.MAX_STRENGTH, "1 pto/nivel");
        addStat(text, "velocidad", dragon.getSpeedLvl(), AncientDragonEntity.MAX_SPEED, "5 ptos/nivel");
        addStat(text, "vida", dragon.getHealthLvl(), AncientDragonEntity.MAX_HEALTH_LVL, "0,5 ptos/nivel");
        addStat(text, "escamas", dragon.getScales(), AncientDragonEntity.MAX_SCALES, "1 pto/escama; cada escama reduce un golpe a la mitad");
        text.append(Component.literal("§7vida_compartida: §f" + (dragon.hasSharedLife() ? "activa" : "no") + " "));
        if (!dragon.hasSharedLife()) {
            text.append(button("Comprar (100 ptos)", "/dragon mejorar vida_compartida", 0xFF55FF,
                    "Tu vida y la del dragón se suman y las comparten los dos"));
        }
        source.sendSystemMessage(text);
        return 1;
    }

    private static void addStat(MutableComponent text, String stat, int level, int max, String hint) {
        text.append(Component.literal("§7" + stat + ": §f" + level + "/" + max + " "));
        text.append(button("+1", "/dragon mejorar " + stat + " 1", 0x55FF55, hint)).append(" ");
        text.append(button("+10", "/dragon mejorar " + stat + " 10", 0x55FF55, hint)).append(" ");
        text.append(button("Máx", "/dragon mejorar " + stat + " 1000", 0xFFAA00, hint)).append("\n");
    }

    private static int upgrade(CommandSourceStack source, String stat, int levels) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        AncientDragonEntity dragon = dragonOf(source);
        if (dragon == null) {
            return 0;
        }
        source.sendSystemMessage(Component.literal(DraconicData.upgrade(player, dragon, stat, levels)));
        return 1;
    }
}
