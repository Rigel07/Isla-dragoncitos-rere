package com.isladragoncitos.system;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.item.DragonCompassItem;
import com.isladragoncitos.worldgen.RiderLore;
import java.util.*;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.levelgen.structure.StructureStart;

public final class DraconicData {
    public static final UUID SHARED_UUID = UUID.fromString("5d6c0888-9356-470f-8988-7cb74c2ac169");
    public static final String SHARED_PREFIX = "isladragoncitos_shared_";

    private static final String ROOT = "PlayerPersisted";
    private static final String KEY = "isladragoncitos";

    private static boolean linking;

    private DraconicData() {}

    private static CompoundTag data(Player player) {
        CompoundTag forge = player.getPersistentData();
        if (!forge.contains(ROOT)) {
            forge.put(ROOT, new CompoundTag());
        }
        CompoundTag persisted = forge.getCompound(ROOT);
        if (!persisted.contains(KEY)) {
            persisted.put(KEY, new CompoundTag());
        }
        return persisted.getCompound(KEY);
    }

    public static int getHalfPoints(Player player) {
        return data(player).getInt("HalfPoints");
    }

    public static void addHalfPoints(Player player, int amount) {
        CompoundTag tag = data(player);
        tag.putInt("HalfPoints", Math.max(0, tag.getInt("HalfPoints") + amount));
    }

    public static String formatPoints(int halfPoints) {
        return halfPoints % 2 == 0 ? String.valueOf(halfPoints / 2) : (halfPoints / 2) + ",5";
    }

    public static int getMarkLevel(Player player) {
        return data(player).getInt("MarkLevel");
    }

    public static void setMarkLevel(Player player, int level) {
        data(player).putInt("MarkLevel", level);
    }

    public static boolean hasAbility(Player player, String abilityId) {
        return data(player).getBoolean("Ability_" + abilityId);
    }

    public static void unlockAbility(Player player, String abilityId) {
        data(player).putBoolean("Ability_" + abilityId, true);
    }

    public static List<String> getUnlockedAbilities(Player player) {
        List<String> abilities = new ArrayList<>();
        CompoundTag tag = data(player);
        // In a real mod, we'd iterate through a known list of IDs
        return abilities;
    }

    public static void setActiveDragon(Player player, AncientDragonEntity dragon) {
        CompoundTag tag = data(player);
        List<UUID> ids = ownedIds(tag);
        if (!ids.contains(dragon.getUUID())) {
            ids.add(dragon.getUUID());
        }
        saveIds(tag, ids);
        tag.putUUID("Dragon", dragon.getUUID());
    }

    private static List<UUID> ownedIds(CompoundTag tag) {
        List<UUID> ids = new ArrayList<>();
        ListTag list = tag.getList("Dragons", Tag.TAG_INT_ARRAY);
        for (int i = 0; i < list.size(); i++) {
            UUID id = NbtUtils.loadUUID(list.get(i));
            if (!ids.contains(id)) ids.add(id);
        }
        if (tag.hasUUID("Dragon") && !ids.contains(tag.getUUID("Dragon"))) {
            ids.add(tag.getUUID("Dragon"));
        }
        return ids;
    }

    private static void saveIds(CompoundTag tag, List<UUID> ids) {
        ListTag list = new ListTag();
        for (UUID id : ids) list.add(NbtUtils.createUUID(id));
        tag.put("Dragons", list);
    }

    @Nullable
    public static AncientDragonEntity findSharedDragon(ServerPlayer player) {
        for (AncientDragonEntity dragon : findDragons(player)) {
            if (dragon.hasSharedLife()) return dragon;
        }
        return null;
    }

    public static List<AncientDragonEntity> findDragons(ServerPlayer player) {
        List<AncientDragonEntity> found = new ArrayList<>();
        for (UUID id : ownedIds(data(player))) {
            AncientDragonEntity dragon = lookup(player, id);
            if (dragon != null) found.add(dragon);
        }
        return found;
    }

    @Nullable
    private static AncientDragonEntity lookup(ServerPlayer player, UUID id) {
        for (ServerLevel level : player.server.getAllLevels()) {
            Entity entity = level.getEntity(id);
            if (entity instanceof AncientDragonEntity dragon && dragon.isAlive() && player.getUUID().equals(dragon.getOwnerUUID())) {
                return dragon;
            }
        }
        return null;
    }

    public static void onHatch(ServerPlayer player, UUID dragonId, int type) {
        CompoundTag tag = data(player);
        int mask = tag.getInt("Hatched") | (1 << type);
        tag.putInt("Hatched", mask);
        if (getMarkLevel(player) < 1) {
            setMarkLevel(player, 1);
            player.displayClientMessage(Component.literal("§6§lMarca del Jinete Nivel 1§r §eha despertado en ti: ventajas duplicadas."), false);
            player.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D, player.getZ(), 60, 0.6D, 1.0D, 0.6D, 0.4D);
        }
    }

    public static void tickPlayer(ServerPlayer player) {
        if (player.tickCount % 10 == 0) {
            sharedLife(player);
        }
    }

    private static void sharedLife(ServerPlayer player) {
        AttributeInstance maxHp = player.getAttribute(Attributes.MAX_HEALTH);
        if (maxHp == null) return;
        AttributeModifier existing = maxHp.getModifier(SHARED_UUID);
        AncientDragonEntity dragon = findSharedDragon(player);
        if (dragon != null && dragon.level() == player.level() && player.isAlive()) {
            double multiplier = getMarkLevel(player) >= 2 ? 2.0 : 1.0;
            double bonus = dragon.getMaxHealth() * multiplier;
            String name = SHARED_PREFIX + dragon.getDragonType();
            if (existing == null || existing.getAmount() != bonus) {
                if (existing != null) maxHp.removeModifier(SHARED_UUID);
                maxHp.addPermanentModifier(new AttributeModifier(SHARED_UUID, name, bonus, AttributeModifier.Operation.ADDITION));
            }
        } else if (existing != null) {
            maxHp.removeModifier(SHARED_UUID);
        }
    }

    public static void onDragonDied(AncientDragonEntity dragon) {
        if (!(dragon.getOwner() instanceof ServerPlayer owner)) return;
        CompoundTag tag = data(owner);
        List<UUID> ids = ownedIds(tag);
        ids.remove(dragon.getUUID());
        saveIds(tag, ids);
        if (tag.getBoolean("Mark")) {
            tag.remove("Mark");
            owner.displayClientMessage(Component.literal("§7La Marca del Jinete se ha desvanecido."), false);
        }
        if (dragon.hasSharedLife() && !linking) {
            linking = true;
            try { owner.kill(); } finally { linking = false; }
        }
    }

    public static void onPlayerDied(ServerPlayer player) {
        if (linking) return;
        AncientDragonEntity dragon = findSharedDragon(player);
        if (dragon != null) {
            linking = true;
            try { dragon.kill(); } finally { linking = false; }
        }
    }
}
