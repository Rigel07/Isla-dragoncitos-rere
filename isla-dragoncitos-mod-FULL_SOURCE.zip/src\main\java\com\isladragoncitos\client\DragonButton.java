package com.isladragoncitos.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Boton con los colores del dragon (fondo oscuro, borde del color del elemento, brillo al pasar el raton). */
public class DragonButton extends Button {
    private final DragonTheme theme;
    /** Pestana o orden activa: se pinta con el color del elemento. */
    public boolean selected;

    public DragonButton(int x, int y, int width, int height, String label, DragonTheme theme, OnPress onPress) {
        super(x, y, width, height, Component.literal(label), onPress, DEFAULT_NARRATION);
        this.theme = theme;
    }

    @Override
    public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int x = this.getX();
        int y = this.getY();
        int fill;
        int text;
        int border;
        if (this.selected) {
            fill = this.theme.accent();
            text = this.theme.dark();
            border = this.theme.light();
        } else if (!this.active) {
            fill = 0xFF1B1B1F;
            text = 0xFF6E6E74;
            border = 0xFF3A3A40;
        } else if (this.isHoveredOrFocused()) {
            fill = DragonTheme.mix(this.theme.mid(), this.theme.accent(), 0.45F);
            text = 0xFFFFFFFF;
            border = this.theme.light();
        } else {
            fill = this.theme.mid();
            text = 0xFFFFFFFF;
            border = this.theme.accent();
        }
        graphics.fill(x, y, x + this.width, y + this.height, fill);
        graphics.renderOutline(x, y, this.width, this.height, border);
        var font = Minecraft.getInstance().font;
        graphics.drawCenteredString(font, this.getMessage(), x + this.width / 2, y + (this.height - 8) / 2, text);
    }
}
