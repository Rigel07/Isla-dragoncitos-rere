package com.isladragoncitos.worldgen;

import com.isladragoncitos.registry.ModBlocks;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** El huevo del dragon del agua: en el fondo del oceano profundo, entre prismarina y una luz marina. */
public class WaterEggFeature extends Feature<NoneFeatureConfiguration> {
    public WaterEggFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        BlockPos floor = origin.below();
        if (!level.getFluidState(origin).is(net.minecraft.tags.FluidTags.WATER) || !level.getBlockState(floor).isSolidRender(level, floor)) {
            return false;
        }
        level.setBlock(origin, ModBlocks.egg(3).defaultBlockState(), 2);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) {
                    continue;
                }
                BlockPos side = origin.offset(dx, 0, dz);
                BlockPos under = side.below();
                if (!level.getFluidState(side).is(net.minecraft.tags.FluidTags.WATER) || !level.getBlockState(under).isSolidRender(level, under)) {
                    continue;
                }
                int r = context.random().nextInt(5);
                BlockState block = r == 0 ? Blocks.SEA_LANTERN.defaultBlockState()
                        : (r <= 2 ? Blocks.PRISMARINE_BRICKS.defaultBlockState() : Blocks.DARK_PRISMARINE.defaultBlockState());
                if (context.random().nextInt(4) != 0) {
                    level.setBlock(side, block, 2);
                }
            }
        }
        return true;
    }
}
