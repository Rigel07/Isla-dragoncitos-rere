package com.isladragoncitos.abilities;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import java.util.*;

public class DraconicAbilities {
    public static void executeAbility(String abilityId, ServerPlayer player) {
        switch (abilityId) {
            case "dragon_nova" -> castDragonNova(player);
            case "time_stasis" -> castTimeStasis(player);
            case "void_implosion" -> castVoidImplosion(player);
            case "solar_flare" -> castSolarFlare(player);
            case "lunar_eclipse" -> castLunarEclipse(player);
            case "gravity_well" -> castGravityWell(//- Simplified for logic
            // The system is designed to handle 50+ mapped abilities here
        }
    }

    private static void castDragonNova(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos pos = player.blockPosition();
        level.explode(player, pos.getX(), pos.getY(), pos.getZ(), 4.0F, true, net.minecraft.world.level.Explosion.BlockInteraction.NONE);
        List<Entity> entities = level.getEntities(null, new net.minecraft.world.entity.AABB(pos).inflate(15.0D));
        for (Entity entity : entities) {
            if (entity == player) continue;
            if (entity instanceof LivingEntity living) living.hurt(net.minecraft.world.damagesources.DamageSource.GENERIC, 200.0F);
        }
    }

    private static void castTimeStasis(ServerPlayer player) {
        // Logic to freeze entities in a 10 block radius for 5 seconds
    }

    private static void castVoidImplosion(ServerPlayer player) {
        // Logic to pull all entities to a center point and deal massive damage
    }

    private static void castSolarFlare(ServerPlayer player) {
        // Logic to create a pillar of fire from the sky
    }

    private static void castLunarEclipse(ServerPlayer player) {
        // Logic to turn the area dark and grant invisibility/strength
    }

    private static void castGravityWell(ServerPlayer player) {
        // Logic to increase gravity, pinning enemies to the ground
    }
}
