package com.isladragoncitos.item;

import com.isladragoncitos.entity.species.DragonSpecies;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.//Cope with tooltips
import java.util.List;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.ChatFormatting;

public class DragonCodexItem extends Item {
    public DragonCodexItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag tooltipFlag) {
        tooltip.add(Component.literal("§6§lLibro del Códice Dracónico§r").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.literal("§7Consulta aquí la enciclopedia de todas las especies."));
        tooltip.add(Component.literal("§eSugerencia: Abre el libro en tu inventario para ver los detalles detallados."));
    }

    // In a full implementation, this would open a GUI (Screen) with a paging system
    // where each page shows the image, description, location, and stats of a species.
}
